import { Component, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, firstValueFrom } from 'rxjs';
import { IonContent, IonFab, IonFabButton, IonFabList, IonIcon, IonBadge } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { hammerOutline, closeOutline, leafOutline } from 'ionicons/icons';

import { ChatbotComponent } from 'src/app/components/chatbot/chatbot.component';
import { ChatData } from 'src/app/core/interfaces/chat-data';
import { MapaService } from 'src/app/core/services/mapa.service';
import { MobiliarioService } from 'src/app/core/services/mobiliario.service';

@Component({
  selector: 'app-mapa',
  templateUrl: './mapa.page.html',
  styleUrls: ['./mapa.page.scss'],
  standalone: true,
  imports: [IonBadge, CommonModule, FormsModule, IonContent, ChatbotComponent]
})
export class MapaPage implements OnInit, OnDestroy {
  @ViewChild('mapContainer', { static: false }) mapContainer!: ElementRef;

  datosIniciales: ChatData | null = null;
  coordenadasMatch: { lat: number; lng: number } | null = null;

  popupVisible = false;
  popupX = 0;
  popupY = 0;
  popupLng = 0;
  popupLat = 0;

  // Interruptor único para cancelar todas las suscripciones en ngOnDestroy
  private destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    private mapaService: MapaService,
    private mobiliarioService: MobiliarioService
  ) {
    addIcons({ hammerOutline, closeOutline, leafOutline });

    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state && navigation.extras.state['coordenadas']) {
      this.coordenadasMatch = navigation.extras.state['coordenadas'];
    }
  }

  ngOnInit() {
    // Escucha unificada y reactiva de los clics en el mapa
    this.mapaService.mapaClick$
      .pipe(takeUntil(this.destroy$))
      .subscribe(coords => {
        if (!this.datosIniciales) return;
      });

    // Suscripción al clic derecho — ahora también se cancela automáticamente
    this.mapaService.clickDerecho$
      .pipe(takeUntil(this.destroy$))
      .subscribe((datos) => {
        this.popupX = datos.x;
        this.popupY = datos.y;
        this.popupLng = datos.lng;
        this.popupLat = datos.lat;
        this.popupVisible = true;
      });
  }

  /**
   * Recibe el evento final cuando el ciudadano rellena los datos mínimos del chatbot
   */
  onChatComponentFinished(event: ChatData) {
    this.datosIniciales = event;
    setTimeout(() => { this.inicializarMapaEnBarrio(event.barrio); }, 100);
  }

  /**
   * Carga la configuración geográfica inicial del barrio seleccionado y arranca la escena
   */
  async inicializarMapaEnBarrio(barrioSeleccionado: string) {
    let centroCoordenadas: [number, number] = [-2.67268, 42.84695];
    let nivelZoom = 13.5;

    try {
      // getBarrios() devuelve el caché — no hay nueva petición HTTP
      const geojsonBarrios = await firstValueFrom(this.mapaService.getBarrios());
      const barrioEncontrado = geojsonBarrios.features.find((f: any) =>
        f.attributes?.TEXTO?.toLowerCase() === barrioSeleccionado.toLowerCase()
      );

      if (barrioEncontrado && (barrioEncontrado as any).properties?.centro) {
        centroCoordenadas = (barrioEncontrado as any).properties.centro;
        nivelZoom = (barrioEncontrado as any).properties.zoom || 15.5;
      }
    } catch (error) {
      console.error('Error al leer el asset de barrios desde el componente:', error);
    }

    if (this.coordenadasMatch) {
      centroCoordenadas = [this.coordenadasMatch.lng, this.coordenadasMatch.lat];
      nivelZoom = 16.5;
    }

    this.mapaService.construirMapa(this.mapContainer.nativeElement, centroCoordenadas, nivelZoom, barrioSeleccionado);

    if (this.coordenadasMatch) {
      this.mapaService.agregarMarcadorEstatico(this.coordenadasMatch.lng, this.coordenadasMatch.lat);
    }
  }

  ngOnDestroy() {
    this.destroy$.next();      // cancela todas las suscripciones con takeUntil
    this.destroy$.complete();  // libera el Subject
    this.mapaService.destruirMapa();
  }
}